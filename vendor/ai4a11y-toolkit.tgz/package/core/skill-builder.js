// The Engineer — the skill builder agent.
//
// Turns a person's plain-language need + their ability profile + the available
// adapter catalog into a real SKILL.md that composes adapters (the diagrams'
// "Skill builder agent"). The LLM is injected (same pattern as the Librarian's
// gemini caller); this module builds the prompt and parses the result. It does
// NOT generate executable code — it authors instructions that name adapters.

import { parseSkill, serializeSkill, validateSkill } from './skill.js';
import { SUPPORT_AREAS } from './ability.js';
import { taxonomy as defaultTaxonomy } from './taxonomy.js';

/**
 * @typedef {import('./skill.js').Skill} Skill
 * @typedef {import('./skill.js').ToolsRegistry & { forPrompt: () => import('./skill.js').ToolPromptEntry[] }} SkillBuilderTools
 *   The registry members the Engineer needs: the prompt catalog on top of the
 *   core's minimum.
 */

/**
 * @typedef {Object} SkillBuildOptions
 * @property {import('./ability.js').ProfileRecord} [profile]  ability profile (supportAreas, freeText)
 * @property {SkillBuilderTools} tools                          AA_TOOLS registry (forPrompt + settingsVocabularyLines)
 * @property {Pick<import('./taxonomy.js').Taxonomy, 'categoryIds'>} [taxonomy]  AA_TAXONOMY (categoryIds) for siteRelevance
 * @property {Skill|null} [previous]                            the prior built Skill the person rejected
 * @property {string} [feedback]                                what the person said was wrong with it
 */

/**
 * Build the prompt that instructs the LLM to author a SKILL.md composing the
 * available adapters for a stated need. Grounds the model in the real adapter
 * catalog + settings vocabulary so it can only reference things that exist.
 *
 * When the person tried a previous attempt and it wasn't right, pass it back
 * with their feedback (`previous` + `feedback`), the diagrams' evaluation
 * loop where a failed validation returns to the skill builder agent.
 *
 * @overload
 * @param {string} need                 - the user's plain-language request
 * @param {SkillBuildOptions} opts
 * @returns {string}
 */
/**
 * FLAG(review): the overload signature above exists so `tools` is required
 * for callers while the runtime default (`= {}`) stays; the alternative is
 * Partial<>, which would let a call with no tools typecheck.
 * The implementation signature keeps the runtime default (`= {}`) legal for
 * the checker; callers see the overload above, where `tools` is required.
 * @param {string} need
 * @param {Partial<SkillBuildOptions> & { tools?: any }} [opts]
 * @returns {string}
 */
export function buildSkillPrompt(need, { profile = {}, tools, taxonomy, previous = null, feedback = '' } = {}) {
  const adapters = tools.forPrompt().map(/** @param {import('./skill.js').ToolPromptEntry} t */ t =>
    `- ${t.id} — ${t.name}: ${t.description} (helps: ${t.supportAreas.join(', ')})`).join('\n');
  const settingsVocab = tools.settingsVocabularyLines().join('\n');
  // Fall back to the bundled taxonomy, the same list validateSkill checks
  // against by default, so the prompt never offers a category that is rejected.
  const categories = (taxonomy || defaultTaxonomy).categoryIds().join(', ');
  const profileBlock = (profile.supportAreas?.length || profile.freeText)
    ? `\nAbout this person:\n- Support areas: ${(profile.supportAreas || []).join(', ') || 'unspecified'}`
      + (profile.freeText ? `\n- In their words: "${profile.freeText}"` : '')
    : '';
  const revisionBlock = (previous && feedback)
    ? `\n\nYou already built this skill for that need:\n\n${serializeSkill(previous)}\n\nThe person tried it and said: "${feedback}"\nRevise the skill to address their feedback. Keep the same name unless the feedback changes what the skill is about, and keep the parts that already worked.`
    : '';

  return `You are the Engineer — an accessibility skill builder. Author a SKILL.md that adapts web pages for the need below by composing EXISTING adapters. You do NOT write code; you write a playbook that names which adapters to apply and with what settings.

The need: "${need}"${profileBlock}${revisionBlock}

Available adapters (use only these ids):
${adapters}

Setting keys and their units/ranges (use only these; values must be in range):
${settingsVocab}

Support areas for supportAreas: ${SUPPORT_AREAS.join(', ')}.
Site categories for siteRelevance: ${categories} (or "all").

Output a COMPLETE SKILL.md, nothing else, in exactly this shape:

---
name: <short-kebab-case-id>
description: <one sentence: what it does and WHEN to use it — this is what an agent matches on>
supportAreas: [<comma-separated support areas from the list above, matching the adapters' "helps" areas>]
siteRelevance: [<comma-separated categories from the list above, or "all">]
---

# <Title>

<1-2 sentences: what this skill does for the person.>

## What it does
<numbered list: each adapter you apply and why, in plain language.>

## When to use
<when it helps and when to skip it.>

## Recipe
\`\`\`json
{
  "adapters": [
    { "id": "<adapter-id>", "settings": { "<key>": <value> } }
  ]
}
\`\`\`

Rules:
- Only reference adapter ids and setting keys listed above. Keep the recipe minimal — 1 to 4 adapters that directly serve the need.
- Only use the support areas and site categories listed above; any other value is rejected. If the person's own support areas use other words, pick the closest listed values instead of copying theirs.
- The "Recipe" JSON is the machine-runnable truth; make the prose match it.
- Prefer the narrowest siteRelevance the need implies; use "all" only for genuinely global needs.`;
}

/**
 * Parse the LLM's SKILL.md output into a validated Skill. Tolerant of code
 * fences the model wraps the whole doc in.
 *
 * @param {string} llmOutput
 * @param {{ tools?: import('./skill.js').ToolsRegistry|null, taxonomy?: import('./skill.js').SkillTaxonomy|null }} [deps]  - taxonomy defaults to the bundled one
 * @returns {{ skill: Skill, valid: boolean, errors: string[] }}
 */
export function parseBuiltSkill(llmOutput, { tools, taxonomy } = {}) {
  let text = String(llmOutput || '').trim();
  // Strip an outer ```markdown / ``` wrapper if the model added one, without
  // touching the inner ```json recipe fence.
  const outer = text.match(/^```(?:markdown|md)?\s*\n([\s\S]*)\n```$/);
  if (outer) text = outer[1].trim();
  const skill = parseSkill(text);
  const { valid, errors } = validateSkill(skill, { tools, taxonomy });
  return { skill, valid, errors };
}

/**
 * Full build helper: prompt the injected LLM, parse + validate, and (if the
 * model referenced anything invalid) return the errors so the caller can
 * re-prompt. Does not persist; the caller (Librarian) owns storage + consent.
 *
 * @overload
 * @param {string} need
 * @param {SkillBuildOptions & { llm?: ((prompt: string) => Promise<string>)|null }} deps
 *   `llm` may be missing or null (the Librarian passes its caller slot as is);
 *   the result then says 'no LLM available' instead of calling anything.
 * @returns {Promise<{ skill: Skill|null, valid: boolean, errors: string[] }>}
 */
/**
 * Implementation signature; see buildSkillPrompt for why it is looser than
 * the overload callers see.
 * @param {string} need
 * @param {Partial<SkillBuildOptions> & { llm?: ((prompt: string) => Promise<string>)|null, tools?: any }} [deps]
 * @returns {Promise<{ skill: Skill|null, valid: boolean, errors: string[] }>}
 */
export async function buildSkill(need, { llm, tools, taxonomy, profile, previous = null, feedback = '' } = {}) {
  if (!llm) return { skill: null, valid: false, errors: ['no LLM available'] };
  const prompt = buildSkillPrompt(need, { profile, tools, taxonomy, previous, feedback });
  let out;
  try {
    out = await llm(prompt);
  } catch (/** @type {any} */ e) {
    return { skill: null, valid: false, errors: [`LLM call failed: ${e.message}`] };
  }
  return parseBuiltSkill(out, { tools, taxonomy });
}
