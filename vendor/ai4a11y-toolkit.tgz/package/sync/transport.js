// Local shared-store transport (Phase 3, increment 5) — §6 transport (a):
// same device, multiple apps, zero accounts. A host that has some store all
// co-located apps can reach (a shared file, an app-group container, a native
// bridge) wraps it in the tiny `shared` surface below; the toolkit PUBLISHES
// granted AbilityModel exports onto it and DRAINS an inbox of insights posted
// by consumer apps.
//
// The permission semantics live entirely in the Librarian — this module never
// bypasses them:
//   - publishExports() writes ONLY what exportAbilityModel() returns, so
//     default-deny / scope-filtering / sharingPaused apply unchanged, and a
//     revoked or paused app's envelope is DELETED on the next publish (the
//     shared copy is retracted, not just no longer refreshed).
//   - drainInbox() feeds each posted insight through importInsight(), so a
//     write is still a grant-gated, whitelisted, never-silent proposal.
//
// Prototype scope: plain JSON envelopes, no signing/encryption (see plan §6
// [product-hardening]). Consumer apps are first-party.

/**
 * @typedef {Object} SharedStore
 * Minimal surface for the device-shared area.
 * @property {(key: string) => Promise<any>} get     undefined when absent.
 * @property {(key: string, value: any) => Promise<void>} set
 * @property {(key: string) => Promise<void>} [remove]  optional; set(key, undefined) is the fallback.
 */

export const EXPORT_PREFIX = 'aa.shared.export.'; // + appId
export const INBOX_KEY = 'aa.shared.inbox';
export const PUBLISHED_INDEX_KEY = 'aa.shared.published'; // [appId] currently published
export const ENVELOPE_VERSION = 1;

// A drain failure is TERMINAL (the entry can never succeed — drop it) vs
// TRANSIENT (would succeed once the user unpauses / switches back — keep it to
// retry). sharing-paused and partition-switched are transient.
/** @type {Set<string|undefined>} */
const TRANSIENT_REASONS = new Set(['sharing-paused', 'partition-switched']);

/**
 * The Librarian methods the transport drives. Structural on purpose: any
 * object with these three methods (a real Librarian, a remote proxy, a test
 * double) can sit on either side.
 * @typedef {Object} TransportLibrarian
 * @property {() => Promise<Array<{ appId: string }>>} listGrants
 * @property {(appId: string) => Promise<{ ok: boolean, abilityModel?: any, reason?: string }>} exportAbilityModel
 * @property {(sourceAppId: string, insight: any) => Promise<{ ok: boolean, reason?: string }>} importInsight
 */

/**
 * @param {SharedStore} shared
 * @param {string} key
 */
async function removeKey(shared, key) {
  if (typeof shared.remove === 'function') await shared.remove(key);
  else await shared.set(key, undefined);
}

/**
 * @param {Object} deps
 * @param {SharedStore} deps.shared  The host-provided device-shared store.
 * @param {{now: () => number}} deps.clock
 */
export function createSharedTransport({ shared, clock }) {
  if (!shared) throw new Error('createSharedTransport: shared store is required');
  if (!clock) throw new Error('createSharedTransport: clock is required');

  return {
    // ---- toolkit (user's device) side ----

    // Refresh the shared copies: one envelope per app that currently passes
    // exportAbilityModel (active grant + sharing not paused); every other
    // app's envelope is DELETED (retracted). The transport OWNS reconciliation
    // via a persisted published-index, so a revoked app is always visited and
    // retracted even if the caller doesn't name it (revoke=delete removes it
    // from listGrants, but its stale envelope must not linger). `appIds` is an
    // optional extra set to consider (e.g. apps requesting for the first time).
    /**
     * @param {TransportLibrarian} librarian
     * @param {string[]|null} [appIds]
     */
    async publishExports(librarian, appIds = null) {
      const grants = await librarian.listGrants();
      const prevIndex = (await shared.get(PUBLISHED_INDEX_KEY)) || [];
      const ids = new Set([...(appIds || []), ...prevIndex, ...grants.map(g => g.appId)]);
      const published = [], retracted = [];
      for (const appId of ids) {
        const res = await librarian.exportAbilityModel(appId);
        const key = EXPORT_PREFIX + appId;
        if (res.ok) {
          await shared.set(key, {
            v: ENVELOPE_VERSION, appId, exportedAt: clock.now(), abilityModel: res.abilityModel,
          });
          published.push(appId);
        } else {
          await removeKey(shared, key); // revoked / paused → retract the shared copy
          retracted.push(appId);
        }
      }
      await shared.set(PUBLISHED_INDEX_KEY, published);
      return { published, retracted };
    },

    // Feed every posted insight through the Librarian's grant-gated,
    // never-silent import. Terminally-failed (malformed / no-grant / bad-insight)
    // and succeeded entries are consumed; TRANSIENTLY-failed entries (sharing
    // paused, partition switched) are KEPT so the next drain retries them once
    // the user unpauses — a paused-window insight is deferred, not lost.
    /** @param {TransportLibrarian} librarian */
    async drainInbox(librarian) {
      const raw = await shared.get(INBOX_KEY);
      const inbox = Array.isArray(raw) ? raw : [];
      const results = [], keep = [];
      for (const entry of inbox) {
        if (!entry || typeof entry.sourceAppId !== 'string' || !entry.insight) {
          results.push({ ok: false, reason: 'malformed' });
          continue;
        }
        const r = { sourceAppId: entry.sourceAppId, ...(await librarian.importInsight(entry.sourceAppId, entry.insight)) };
        results.push(r);
        if (!r.ok && TRANSIENT_REASONS.has(r.reason)) keep.push(entry);
      }
      await shared.set(INBOX_KEY, keep);
      return results;
    },

    // ---- consumer-app side (what XR / ArtInsight call) ----

    /** @param {string} appId */
    async readExport(appId) {
      const env = await shared.get(EXPORT_PREFIX + appId);
      return env && env.v === ENVELOPE_VERSION ? env : null;
    },

    /**
     * @param {string} sourceAppId
     * @param {any} insight
     */
    async postInsight(sourceAppId, insight) {
      const inbox = (await shared.get(INBOX_KEY)) || [];
      inbox.push({ v: ENVELOPE_VERSION, sourceAppId, sentAt: clock.now(), insight });
      await shared.set(INBOX_KEY, inbox);
    },
  };
}

export default createSharedTransport;
